# IMDB Sentiment Classifier

A minimal, résumé‑ready NLP project that fine‑tunes DistilBERT on the IMDB sentiment‑analysis dataset.

## Quickstart

```bash
git clone <repo‑url>
cd sentiment-imdb
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m src.cli train --epochs 1 --output_dir ./checkpoints
```

## Project layout

* **src/** – reusable modules (`data.py`, `model.py`) and a small CLI wrapper (`cli.py`)
* **notebooks/demo.ipynb** – exploratory analysis & inference demo
* **tests/** – smoke test that runs in < 30 s with `pytest`
* **requirements.txt** – pinned versions for full reproducibility

## Inference example

```python
from transformers import pipeline
classifier = pipeline("sentiment-analysis", model="./checkpoints")
print(classifier("I loved this movie!"))
```

## License

MIT
